# Earth Day Countdown Webpage

## Overview
This project is a simple yet informative webpage dedicated to Earth Day 2024. It features a countdown timer to Earth Day, detailed information about the day, its significance, and ways to reduce carbon footprints. The webpage also includes links to external resources, a gallery of Earth Day images I created, an embedded video about Earth Day statistics, and a small generic table of important Earth Day facts.

## Features
- **Countdown Timer**: A dynamic countdown to Earth Day 2024, updating every second.
- **Informative Sections**: Detailed sections about Earth Day, including its history, significance, and tips for reducing carbon footprints.
- **External Links**: Links to the official Earth Day website, historical information, and activities related to Earth Day.
- **Image Gallery**: A collection of images celebrating Earth Day.
- **Embedded Video**: An informative video about Earth Day, embedded from YouTube.
- **Facts Table**: A table displaying key facts about Earth Day.

## Technologies Used
- HTML: For structuring the webpage content.
- CSS: For styling and responsive design.
- JavaScript: For the countdown timer functionality.

## Setup and Usage
1. Clone the repository to your local machine.
2. Open the `index.html` file in a web browser to view the webpage.
3. The webpage is best viewed on modern browsers like Chrome, Firefox, Safari, and Edge.


https://github.com/MagicalMaravilla/Assignment-1-CS-290/tree/main

Created with ❤️ for Earth Day 2024.